package rental;

import rental.model.Car;
import rental.model.Customer;
import rental.model.Motorcycle;
import rental.model.RentalAgency;
import rental.model.RentalTransaction;
import rental.model.Truck;
import rental.model.Vehicle;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RentalAgency agency = new RentalAgency("AG001", "Rent-A-Vehicle");

        Vehicle car = new Car("CAR001", "Toyota Camry", 40.0, 4);
        Vehicle motorcycle = new Motorcycle("MOTO001", "Honda CBR500R", 20.0, 500);
        Vehicle truck = new Truck("TRUCK001", "Ford F-150", 60.0, 2000);

        agency.addVehicle(car);
        agency.addVehicle(motorcycle);
        agency.addVehicle(truck);

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Vehicle Rental System");
            System.out.println("1. Display available vehicles");
            System.out.println("2. Rent a vehicle");
            System.out.println("3. Return a vehicle");
            System.out.println("4. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            switch (choice) {
                case 1:
                    System.out.println("Available vehicles:");
                    for (Vehicle vehicle : agency.getVehicles()) {
                        System.out.println(vehicle.toString());
                    }
                    break;
                case 2:
                    System.out.print("Enter customer name: ");
                    String customerName = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String customerEmail = scanner.nextLine();
                    Customer customer = new Customer("CUST001", customerName, customerEmail);

                    System.out.print("Enter vehicle ID: ");
                    String vehicleId = scanner.nextLine();
                    Vehicle vehicle = agency.getVehicle(vehicleId);

                    if (vehicle != null) {
                        System.out.print("Enter rental date (yyyy-mm-dd): ");
                        String rentalDateStr = scanner.nextLine();
                        LocalDate rentalDate = LocalDate.parse(rentalDateStr);
                        System.out.print("Enter return date (yyyy-mm-dd): ");
                        String returnDateStr = scanner.nextLine();
                        LocalDate returnDate = LocalDate.parse(returnDateStr);

                        RentalTransaction transaction = new RentalTransaction("TRANS001", vehicle, customer, rentalDate, returnDate, vehicle.calculateRentalCost(1));
                        agency.addRentalTransaction(transaction);
                        System.out.println("Vehicle rented successfully!");
                    } else {
                        System.out.println("Vehicle not found!");
                    }
                    break;
                case 3:
                    System.out.print("Enter transaction ID: ");
                    String transactionId = scanner.nextLine();
                    RentalTransaction transaction = agency.getRentalTransaction(transactionId);

                    if (transaction != null) {
                        agency.returnVehicle(transaction);
                        System.out.println("Vehicle returned successfully!");
                    } else {
                        System.out.println("Transaction not found!");
                    }
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}