package rental.model;

import java.util.ArrayList;
import java.util.List;

    public class RentalAgency {
            private String agencyId;
            private String name;
            private List<Vehicle> vehicles;
            private List<RentalTransaction> rentalTransactions;

            public RentalAgency(String agencyId, String name) {
                this.agencyId = agencyId;
                this.name = name;
                this.vehicles = new ArrayList<>();
                this.rentalTransactions = new ArrayList<>();
            }

            public String getAgencyId() {
                return agencyId;
            }

            public void setAgencyId(String agencyId) {
                this.agencyId = agencyId;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public List<Vehicle> getVehicles() {
                return vehicles;
            }

            public void addVehicle(Vehicle vehicle) {
                this.vehicles.add(vehicle);
            }

            public void removeVehicle(Vehicle vehicle) {
                this.vehicles.remove(vehicle);
            }

            public List<RentalTransaction> getRentalTransactions() {
                return rentalTransactions;
            }

            public void addRentalTransaction(RentalTransaction rentalTransaction) {
                this.rentalTransactions.add(rentalTransaction);
            }

            public void removeRentalTransaction(RentalTransaction rentalTransaction) {
                this.rentalTransactions.remove(rentalTransaction);
            }

        public RentalTransaction getRentalTransaction(String transactionId) {
            return null;
        }

        public void returnVehicle(RentalTransaction transaction) {
        }

        public Vehicle getVehicle(String vehicleId) {
            return null;
        }
    }
