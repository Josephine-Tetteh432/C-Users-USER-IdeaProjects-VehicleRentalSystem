package rental.model;

    public class Truck extends Vehicle {
        private int cargoCapacity;

        public Truck(String vehicleId, String model, double baseRentalRate, int cargoCapacity) {
            super(vehicleId, model, baseRentalRate);
            this.cargoCapacity = cargoCapacity;
        }

        public int getCargoCapacity() {
            return cargoCapacity;
        }

        public void setCargoCapacity(int cargoCapacity) {
            this.cargoCapacity = cargoCapacity;
        }

        @Override
        public double calculateRentalCost(int days) {
            return getBaseRentalRate() * days;
        }

        @Override
        public boolean isAvailableForRental() {
            return isAvailable();
        }
    }
