package rental.model;

    public class Motorcycle extends Vehicle {
        private int engineCapacity;

        public Motorcycle(String vehicleId, String model, double baseRentalRate, int engineCapacity) {
            super(vehicleId, model, baseRentalRate);
            this.engineCapacity = engineCapacity;
        }

        public int getEngineCapacity() {
            return engineCapacity;
        }

        public void setEngineCapacity(int engineCapacity) {
            this.engineCapacity = engineCapacity;
        }

        @Override
        public double calculateRentalCost(int days) {
            return getBaseRentalRate() * days;
        }

        @Override
        public boolean isAvailableForRental() {
            return isAvailable();
        }
    }